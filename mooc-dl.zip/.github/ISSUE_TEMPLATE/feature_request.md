---
name: Feature request
about: Suggest an idea for this project
title: "✨ "
labels: ""
assignees: ""
---

## 特性描述

<!-- 请在这里详述你所需要的特性 -->

## 是否愿意为此贡献代码

<!-- 如果你愿意，欢迎贡献～ -->
